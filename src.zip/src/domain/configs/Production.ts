export type ProductionTypes =
    | 'soup';